package com.collection.book;

public class Marksheet {
	public String rollNo;
	public String name;
	public int marks;
	

}
