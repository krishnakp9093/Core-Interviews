package com.collection.book;

import java.util.Properties;

public class TestProperties {
	public static void main(String[] args) {
		Properties p = new Properties();
		p.put(9, "rohit");  //it will arrange in Ascending order
		p.put(1, "krishna");
		p.put(5, "raj");
		p.put(10, "haren");
		
		System.out.println(p);
//Some common methods of hastable like contains , containskey , entrySet, size,hashcode etc....
	
	}

}
