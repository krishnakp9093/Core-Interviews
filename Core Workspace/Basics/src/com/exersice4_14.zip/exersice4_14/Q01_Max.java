package com.exersice4_14;

public class Q01_Max {
	public static void main(String[] args) {
		int a = 10;
		int b = 2;
		
		if(a> b) {
			System.out.println( " maximum number is = " + a);
		}else {
			System.out.println("maximum number is = " + b);
		}
		
	}

}
