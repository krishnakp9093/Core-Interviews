package com.exersice4_14;

public class Q02_Smaller {
	public static void main(String[] args) {
		int a = 10;
		int b = 2;
		
		if(a < b) {
			System.out.println("smaller number is = " + a);
		}else {
			System.out.println("smaller number is = " + b);
		}
	}

}
