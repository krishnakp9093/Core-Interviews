package com.exersice4_14;

public class Q13_HarmonicSeries {
	public static void main(String[] args) {
		
	
	int p  = 20;
//	double sum = 0;
	for(int i =1 ; i<= p ; i++) {
	//	sum = sum + (double)1/i;
		System.out.print("  + 1/"+i);
		
		
	}
//System.out.println("\n"+sum);
}


}

